# Major Project Changelog

## Template
**Use either 2023-12-12 or 12Dec2023 for date format**

Name, Date
- Change Notes
- Change Notes

Fox, 12Dec2023
- Change Notes
- Change Notes

## Enter Your Log Entries Below

Vincent, 26Dec2023
- Created Github Repository
- Push Boilerplate codes for p5.js

Vincent, 27-30Dec2023
- Implemeted first fluid simulation based on the Jos Stam and Mike Ash papers.
- Things work very well.
- I have documented the code fairy good.
- But this implementation is not really what we want.
- I deleted the whole code and start again, this time using the Ten Minutes Physics implementation.
- Javascript is getting slow.
- Nah Bro, forget it. We moving to Java again.

  
Ethan, 08Jan2024
- Finished the constructor for the Fluid class.
- Vincent is having the temptation to copy/paste the whole code.

Ethan, 09Jan2024
- Finsihed the set_bnd, avg_Vy, avg_Vx methods.
- Getting comfortable with 2d arrays indecies.
- Literally wrote 2 lines of code, called it a day

Ethan, 10Jan2024
- Finished the rest of the methods.
- Method to enforce fluid incompressibility (project())
- Method to sample and interpolate grid values (sampleField())
- Methods to addvect velocities and fluid densities.
- Document and comment the code based on what I understand so far...

Vincent, 10Jan2024
- Waiting for Ethan to finish the Fluid class.
- Create Helper method to copy 2d float array.

Ethan, 11Jan2024
- Implement another helper method to create a 2d float array and fill it with given values.
- Finsihing up the Fluid class.

Vincent, 11Jan2024
- Debug array indexing bugs, really annoying to catch it.
- Mostly debugging runtime errors for today.

Ethan, 12Jan2024
- Setting up the processing sketch to run and render the fluid simulation.
- Set up the simulation grid dimensions and size to match the user's screen aspect ratios.
- Fix any occuring bugs.

Vincent, 12Jan2024
- Ethan setup the sketch and it ran smoothly without bugs (so far...)
- The fluid density is not addvecting correctly.
- We are tressing out, not sure if it the error in the render method or the advection method.
- If the error is in the advection methods we are screwed (they are wildly complicated).

Vincent, 13Jan2024
- The debugging process continues, it gets more painful the more time I spent.
- Made sure I update the addvection of velocities and density.
- Made sure the screen aspect ratio and the class parameters are correct.
- Watch a Youtube video about pencils.
- Tested to see if the choice of float (7 decimal points accuracy) is the problem. Not the case...
- Compared with my javascript implmentation. They are virtually the same but the Java is not working...
- I lied to Ethan that I fixed the code, God knows I didn't.
- I really have no idea what is causing this. I pray every single nights.

Vincent, 15Jan2024
- Continue to try to narrow down the bug sources.
- Look at Morgan's bugs, he fixed all of them and I didn't fix even one for the whole class.
- The pain is growing.
- At the end of class, I think I might narrow it down to the density addvection method.
- No, maybe it was the sampleField method used inside the addvection methods.  

Ethan, 12-15Jan2024
- Suffering fatal diarrhea, literally dying

Vincent, 16Jan2024
- IT WAS THE DAMN SAMPLEFIELD METHOD.
- I PUT THE INTERPOLATION FORMULA WRONG BY LITERALLY TWO INDICIES
- I WASTED TOO MANY TIME ON THIS DAMN BUG
- I DON'T EVEN FEEL SATISFIED, I'M MAD ABOUT MYSELF.
- Calmed myself down, decided to start documenting the code for Mr. Fox.
- I didn't expect it but Java loops are atleast 5 times faster than those of Javascript. Switching back to Java Processing was the right choice.

Vincent, 17Jan2024
- 

Ethan, 182024
- Swearing in class today.
- got punched by Morgan
  
Vincent, 18Jan2024
-

Vincent, 21Jan2024
- Tried to implement a better set_bnd method.
- The new set_bnd method is complex but it's effects are insignificant, so I revert back to the old method.
- Tried to implement a Player class (a simple triangle).
- Implement array to keep record of keys pressed.
- Implement the controls for the player object to move and accelerate.
- Maybe I should create circles floating objects.

Vincent, 22Jan2024
- Played around with the color method to see if I can make any imorovement.
- Got new background
- The border edges seem to be causing the program to crash...
- Create Balls class to place balls on the screen
- The balls will accelerate based in the velocity field of the fluid
- Implement drag force in the fluid.
- Should I implement collision detection on them balls???

Vincent, 23Jan2024
- Added drag force on player
- Player is now influenced by velocity field
- Why did I even create a Player object?

Ethan, 25Jan2024
- Fixed anoying bug that cause program to crash at edge borders.
- Created method to load random images
- Made image change every 10 seconds
- Created some memes for Mr. Fox
- Finishing up our loosely project.


                        THE END
- This was a great class, we didn't regret a single second of it.
- Thank you Mr. Fox, it was an honour being your CS student.